export default {
  base: "./",
};
