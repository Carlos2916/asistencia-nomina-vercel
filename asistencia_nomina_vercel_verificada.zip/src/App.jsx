import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center text-2xl text-green-700 font-bold">
      ✅ App cargó correctamente y está lista para Vercel
    </div>
  );
}
